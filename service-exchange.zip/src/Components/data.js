const team = [
  {
    id: 1,
    image:
      "https://res.cloudinary.com/dbiqsk9jz/image/upload/v1612429774/samples/people/bicycle.jpg",
    name: "Maja Marek",
    title: "content manager",
    quote:
      "Life imposes things on you that you can’t control, but you still have the choice of how you’re going to live through this.",
  },
  {
    id: 2,
    image:
      "https://res.cloudinary.com/dbiqsk9jz/image/upload/v1612429770/samples/people/smiling-man.jpg",
    name: "Ion Chircu",
    title: "web-developer",
    quote:
      "Your work is going to fill a large part of your life, and the only way to be truly satisfied is to do what you believe is great work. And the only way to do great work is to love what you do. If you haven’t found it yet, keep looking. Don’t settle. As with all matters of the heart, you’ll know when you find it.",
  },
  {
    id: 3,
    image:
      "https://res.cloudinary.com/dbiqsk9jz/image/upload/v1612429774/samples/people/bicycle.jpg",
    name: "Nargiza Rysmendieva",
    title: "content manager",
    quote:
      "Life imposes things on you that you can’t control, but you still have the choice of how you’re going to live through this.",
  },
  {
    id: 4,
    image:
      "https://res.cloudinary.com/dbiqsk9jz/image/upload/v1612429774/samples/people/bicycle.jpg",
    name: "Ljiljana Bagaric",
    title: "content manager",
    quote:
      "Life imposes things on you that you can’t control, but you still have the choice of how you’re going to live through this.",
  },
  {
    id: 5,
    image:
      "https://res.cloudinary.com/dbiqsk9jz/image/upload/v1612429774/samples/people/bicycle.jpg",
    name: "Shih-chen Chao",
    title: "content manager",
    quote:
      "Life imposes things on you that you can’t control, but you still have the choice of how you’re going to live through this.",
  },
];

export default team;
